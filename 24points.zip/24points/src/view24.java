import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class view24 extends JFrame implements ActionListener {

	/**
	 * @param args
	 */
private JTextField user_inputarea_1 = new JTextField();	
private JTextField user_inputarea_2 = new JTextField();
private JTextField user_inputarea_3 = new JTextField();
private JTextField user_inputarea_4 = new JTextField();
private JButton start = new JButton("start");
private JButton reset = new JButton("reset");
private JScrollPane outputareaPane;
private JTextArea outputarea = new JTextArea();
	
private controller24 mController;

public view24() {
	this.setTitle("24 points");
	user_inputarea_1.setPreferredSize(new Dimension(40,40));
	user_inputarea_2.setPreferredSize(new Dimension(40,40));
	user_inputarea_3.setPreferredSize(new Dimension(40,40));
	user_inputarea_4.setPreferredSize(new Dimension(40,40));
	JPanel content = new JPanel();
	content.setLayout(new BorderLayout());
	JLabel label = new JLabel("Input four cards");
	content.add(label,BorderLayout.NORTH);
	JPanel middleContent = new JPanel();
	middleContent.setLayout(new FlowLayout());
	middleContent.add(this.user_inputarea_1);
	middleContent.add(this.user_inputarea_2);
	middleContent.add(this.user_inputarea_3);
	middleContent.add(this.user_inputarea_4);
	content.add(middleContent,BorderLayout.CENTER);
	JPanel bottomContent = new JPanel();
	bottomContent.setLayout(new FlowLayout());
	bottomContent.add(this.start);
	bottomContent.add(this.reset);
	content.add(bottomContent,BorderLayout.SOUTH);
	JPanel rightContent = new JPanel();
	outputareaPane = new JScrollPane(outputarea,
			ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
	outputareaPane.setPreferredSize(new Dimension(150,75));
	content.add(outputareaPane,BorderLayout.EAST);
	this.setContentPane(content);
	this.pack();
	this.setResizable(false);
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	this.start.addActionListener(this);
	this.reset.addActionListener(this);
}

public String getUserInput(int i) {
	if (i == 1)
	{
    return this.user_inputarea_1.getText();
   
	}
	else if ( i == 2)
	{
	return this.user_inputarea_2.getText();	
	}
	else if ( i == 3)
	{
	return this.user_inputarea_3.getText();
	}
	else
	{
	return this.user_inputarea_4.getText();
	}
}

public int convert_input(String str)
{
	int input;
if (str.equals("1"))
{
input = 1;	
}
else if (str.equals("2"))
{
input = 2;	
}
else if (str.equals("3"))
{
input = 3;	
}
else if (str.equals("4"))
{
input = 4;	
}
else if (str.equals("5"))
{
input = 5;	
}
else if (str.equals("6"))
{
input = 6;	
}
else if (str.equals("7"))
{
input = 7;	
}
else if (str.equals("8"))
{
input = 8;	
}
else if (str.equals("9"))
{
input = 9;	
}
else if (str.equals("10"))
{
input = 10;	
}
else if (str.toLowerCase().equals("a"))
{
input = 1;	
}
else if (str.toLowerCase().equals("j") || str.toLowerCase().equals("q") || str.toLowerCase().equals("k"))
{
input = 10;
}
else 
{
input = -1;
}
return input;
}

public void showError(int i)
{
if (i == 0)
{
	System.out.println("Invalid input");
}
else if ( i == 1)
{
	System.out.println("Input number is not correct");
}
}
public void registerController(controller24 controller) {
    this.mController = controller;
}

@Override
public void actionPerformed(ActionEvent e) {
if (e.getSource().equals(this.start))
{
this.mController.handleStartEvent();	
}
else
{
this.mController.handleResetEvent();	
}
	
}

public void output(String result) {

this.outputarea.setText(result);
	
}

public void reset() {
this.outputarea.setText("");
this.user_inputarea_1.setText("");
this.user_inputarea_2.setText("");
this.user_inputarea_3.setText("");
this.user_inputarea_4.setText("");
}
}

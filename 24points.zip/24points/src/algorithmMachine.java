public class algorithmMachine {

	private float data[];

	private float number1, number2;

	public algorithmMachine(int[] input) {
		data = new float[4];
		for (int i = 0; i < input.length; i++) {
			int temp = input[i];
			float updata = (float) temp;
			data[i] = updata;
		}
	}

	public void outputData() {
		System.out.println("the data is ");
		for (int i = 0; i < 4; i++) {
			System.out.print(data[i] + " ");
		}
	}

	public float calculate(float x, float y, int op) {
		if (op == 0) {
			return x + y;
		} else if (op == 1) {
			return x - y;
		} else if (op == 2) {
			return y - x;
		} else if (op == 3) {
			return x * y;
		} else if (op == 4) {
			return x / y;
		} else {
			return y / x;
		}
	}

	public String run() {
		String str = this.testCase1(data);
		return str;
	}

	public String testCase1(float[] array)
	{
		for ( int i=0 ; i < 4; i++)
		{
			for ( int j = 0; j < 4; j++)
			{
				if ( j != i)
				{
				for ( int k = 0; k < 4; k++)
				{
					if (k != i && k != j)
					{
					for (int m =0; m < 4; m++)
					{
						if ( m !=i && m!=j && m!= k)
						{
						for (int a = 0; a < 6; a++)
						{	
							for (int b = 0; b < 6; b++)
							{
								for (int c =0; c < 6; c++)
								{
									float result = calculate(array[i],array[j], a);
									result = calculate(result, array[k], b);
									result = calculate(result, array[m], c);
									if (result == 24) {
										float temp1 = calculate(array[i],array[j], a);
										float temp2 = calculate(temp1, array[k], b);
										float temp3 = calculate(temp2, array[m], c);
										String str = printOp(array[i],array[j], a) + " = " +Float.toString(temp1)
												+ " ; \n" 
												+ printOp(temp1,array[k], b) + " = " +Float.toString(temp2)
											    + " ; \n"
											    + printOp(temp2,array[m], c) + " = " +Float.toString(temp3);
											return str;
										}
								}
							}
						}
						}
					}
					}
				}
				}
			}
		}
		return "no answer";
	}
	private String printOp(float x, float y, int op) {
		String str;
		if (op == 0) {
			str = Float.toString(x) + " + " + Float.toString(y);
		} else if (op == 1) {
			str = Float.toString(x) + " - " + Float.toString(y);
		} else if (op == 2) {
			str = Float.toString(y) + " - " + Float.toString(x);
		} else if (op == 3) {
			str = Float.toString(x) + " * " + Float.toString(y);
		} else if (op == 4) {
			str = Float.toString(x) + " / " + Float.toString(y);
		} else {
			str = Float.toString(y) + " / " + Float.toString(x);
		}
		return str;
	}

}
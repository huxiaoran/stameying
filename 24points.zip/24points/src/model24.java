
public class model24 {

	private int size;
	private int input[], buffer[];
	private algorithmMachine machine;
	public model24()
	{
		this.size = 0;
		this.input = new int[4];
		this.buffer = new int[4];
	}
	
	public void addInput( int temp) {
	this.buffer[size] = temp;
	this.size++;
	}

	public int getSize() {
		return this.size;
	}

	public void updateInput() {
		for (int i =0 ; i< 4; i++)
		{
			this.input[i] = this.buffer[i];
		}
		
	}
	public void resetBufferSize()
	{
		this.size =0;
	}
	
	public void reset()
	{
		this.size =0 ;
		for (int i=0; i< 4; i++)
		{
			input[i] = 0;
			buffer[i] = 0;
		}
	}
	public String run() {
		machine = new algorithmMachine(input);
		String str = machine.run();
		return str;
	}

	
	
}

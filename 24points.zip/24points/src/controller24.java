
public class controller24 {
	private view24 m_View;
	private model24 m_Model;
	
	
	public controller24(model24 model, view24 view) {
		this.m_Model = model;
		this.m_View = view;
		
		view.registerController(this);
	}
	
	public void handleStartEvent() {
		m_Model.resetBufferSize();
		for (int i = 1; i <=4 ; i++)
		{
			String str;
			str	= m_View.getUserInput(i);
			int temp;
			temp = m_View.convert_input(str);
			if (temp != -1)
			{
				m_Model.addInput(temp);
			}
			else 
			{
				m_View.showError(0);
				this.handleResetEvent();
			}
		}
		this.checkInput();
		m_Model.updateInput();
		String result = m_Model.run();
		m_View.output(result);
	}

	public void checkInput() {
		if (m_Model.getSize() != 4)
		{
			m_View.showError(1);
			this.handleResetEvent();
		}
	}

	public void handleResetEvent() {
		m_View.reset();
		m_Model.reset();
		
	}

	/**
	 * @param args
	 */


}

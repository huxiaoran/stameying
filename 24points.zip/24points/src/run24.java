
public class run24 {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		view24 view = new view24();
		model24 model = new model24();
		controller24 controller = new controller24(model,view);
		view.setVisible(true);
	}

}
